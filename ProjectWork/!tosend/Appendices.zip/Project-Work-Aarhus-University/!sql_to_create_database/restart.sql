\. drop.sql
\. create.sql
\. insert.sql