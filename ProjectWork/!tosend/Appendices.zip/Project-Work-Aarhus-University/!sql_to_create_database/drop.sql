drop table if exists Entry;
drop table if exists Habit;
drop table if exists User;
